/**
 * Contains three classes: {@link pl.polsl.model.StudentModel} and {@link pl.polsl.model.SubjectModel} and {@link pl.polsl.model.WrongGradeException}
 * that implements main data structures to the program
 */
package pl.polsl.model;
