/**
 * Contains a class {@link pl.polsl.controller.StudentController} needed for interaction between model and view
 */
package pl.polsl.controller;
