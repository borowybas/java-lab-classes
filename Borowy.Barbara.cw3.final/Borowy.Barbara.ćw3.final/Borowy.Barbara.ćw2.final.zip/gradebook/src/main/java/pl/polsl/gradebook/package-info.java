/**
 * Contains one class {@link pl.polsl.gradebook.Main} that starts the program and initiates first values and objects
 */
package pl.polsl.gradebook;
