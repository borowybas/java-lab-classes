/**
 * Contains three classes: {@link pl.polsl.model.StudentModelTest} and {@link pl.polsl.model.SubjectModelTest} 
 * and {@link pl.polsl.model.WrongGradeExceptionTest}
 * that implements tests for main function of model classes
 */
package pl.polsl.model;
