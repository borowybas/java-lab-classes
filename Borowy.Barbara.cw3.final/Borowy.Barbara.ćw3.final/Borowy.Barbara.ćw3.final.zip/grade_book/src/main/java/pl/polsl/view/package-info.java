/**
 * Contains one class: {@link pl.polsl.view.StudentView} that provides comunication with user
 */
package pl.polsl.view;
