/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package pl.polsl.grade_book;

import pl.polsl.model.StudentModel;
import pl.polsl.model.SubjectModel;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

import javafx.scene.control.TreeTableColumn;
import javafx.scene.control.TreeTableView;
import javafx.scene.control.cell.TreeItemPropertyValueFactory;
/**
 * FXML Controller class
 *
 * @author Admin
 */
public class TestController implements Initializable {


    @FXML
    private TreeTableView<SubjectModel> table;
    @FXML
    private TreeTableColumn<SubjectModel, String> c1;
    @FXML
    private TreeTableColumn<SubjectModel, String> c2;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //c1.
        TreeTableView<SubjectModel> treeTableView = new TreeTableView<SubjectModel>();
        table = new TreeTableView<SubjectModel>();
        
        c1 = new TreeTableColumn<>("Subj");
        c2 = new TreeTableColumn<>("Grades");
        
        c1.setCellValueFactory(new TreeItemPropertyValueFactory<>("subj"));
        c2.setCellValueFactory(new TreeItemPropertyValueFactory<>("grades"));
        

        
        
        table.getColumns().add(c1);
        table.getColumns().add(c2);
        
        
       
    }    
    
}
