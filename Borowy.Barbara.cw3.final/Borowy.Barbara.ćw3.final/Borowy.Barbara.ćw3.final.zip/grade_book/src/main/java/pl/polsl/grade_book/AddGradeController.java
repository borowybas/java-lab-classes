/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package pl.polsl.grade_book;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import pl.polsl.model.StudentModel;
import pl.polsl.model.SubjectModel;
import pl.polsl.model.WrongGradeException;
/**
 * FXML Controller class
 *
 * @author Admin
 */
public class AddGradeController{


    @FXML
    private Button addGradeButton;
       
    private StudentModel model;
    @FXML
    private TextField subjectName;
    @FXML
    private TextField grade;
    
    @FXML
    private void addGrade(ActionEvent event) throws IOException {
        
        String subName= subjectName.getText();
        float gradeT = Float.parseFloat(grade.getText());
        
        boolean flag = false;
        for(SubjectModel subject: model.getStudentSubjects()){
            if (subject.getSubjectName().equals(subName)){
                //dodaj ocene
                flag = true;
                try{
                    subject.addGrade(gradeT);}
                catch(WrongGradeException e){
                    System.err.println(e.getMessage());
                }
            }
        }
        if(flag == false){
            model.addSubject(new SubjectModel(subName));
            for(SubjectModel subject: model.getStudentSubjects()){
               if (subject.getSubjectName().equals(subName)){
                //dodaj ocene
                try{
                     subject.addGrade(gradeT);
                }
                catch(WrongGradeException e){
                        System.err.println(e.getMessage());
                }
                }
            }
        }
        
        App.setRoot("mainPage");
        
    }
    
    public void setModel(StudentModel model){
        this.model = model;
    }

}
