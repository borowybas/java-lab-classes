/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package pl.polsl.grade_book;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import pl.polsl.model.StudentModel;
import pl.polsl.model.SubjectModel;
import pl.polsl.model.WrongGradeException;

/**
 * FXML Controller class
 *
 * @author Admin
 */
public class MainPageController implements Initializable{

    @FXML
    private TextField name;
    @FXML
    private Button enterNameButton;
    @FXML
    private Button addGradeButton;
    @FXML
    private Button printGradesButton;
    @FXML
    private Button exitButton;

    private StudentModel model;
    @FXML
    private TextField subjectName;
    @FXML
    private TextField grade;
    @FXML
    private TextArea infoText;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        model = new StudentModel();
    }
    
    @FXML
    private void enterName(ActionEvent event) {
        this.model.setStudentName(name.getText());
    }

    @FXML
    private void addGrade(ActionEvent event) throws IOException {        
        
        
        if( subjectName.getText() == null || subjectName.getText().trim().isEmpty() || subjectName.getText().isEmpty()|| subjectName.getText().trim().equals("")||
                subjectName.getText().equals("")  ){
            infoText.setText("Incorrect subject name"); return;
        }else if (grade.getText().equals("") ||  Float.parseFloat(grade.getText())<2 || Float.parseFloat(grade.getText())>5 ){
            infoText.setText("Incorrect grade"); return;
        }       
        else{
            String subName = subjectName.getText();
            float gradeT = Float.parseFloat(grade.getText());
            infoText.setText("correct input");
        boolean flag = false;
        for(SubjectModel subject: model.getStudentSubjects()){
            if (subject.getSubjectName().equals(subName)){
                //dodaj ocene
                flag = true;
                try{
                    subject.addGrade(gradeT);}
                catch(WrongGradeException e){
                    System.err.println(e.getMessage());
                }
            }
        }
        if(flag == false){
            model.addSubject(new SubjectModel(subName));
            for(SubjectModel subject: model.getStudentSubjects()){
               if (subject.getSubjectName().equals(subName)){
                //dodaj ocene
                try{
                     subject.addGrade(gradeT);
                }
                catch(WrongGradeException e){
                        System.err.println(e.getMessage());
                }
                }
            }
        }
        }
        
        
    }

    @FXML
    private void printGrades(ActionEvent event) throws IOException {
        //App.setRoot("printGrades");
        FXMLLoader loader = new FXMLLoader(getClass().getResource("printGrades.fxml"));
        Parent root = loader.load();
        ((PrintGradesController)loader.getController()).setModel(this.model);
        Stage stage = new Stage();
        stage.setTitle("Print grades");
        stage.setScene(new Scene(root));
        stage.show();
        
    }

    @FXML
    private void exit(ActionEvent event) {
        App.close(exitButton);
    }
    
}
