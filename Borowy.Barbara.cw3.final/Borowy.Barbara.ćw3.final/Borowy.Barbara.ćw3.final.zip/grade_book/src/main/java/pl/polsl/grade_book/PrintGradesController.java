/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package pl.polsl.grade_book;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

import javafx.scene.control.Button;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeTableColumn;
import javafx.scene.control.TreeTableView;
import javafx.scene.control.cell.TreeItemPropertyValueFactory;
import javafx.util.Callback;
import pl.polsl.model.StudentModel;
import pl.polsl.model.SubjectModel;
/**
 * FXML Controller class
 *
 * @author Barbara Borowy
 * @version 1.0
 */
public class PrintGradesController {


    //@FXML
   // private Button exitButton;
        
    @FXML
    private TreeTableColumn<String, String> gradesColumn;

    @FXML
    private TreeTableColumn<String, String> subjectColumn;

    @FXML
    private TreeTableView<String> treeTableView;
    
    private StudentModel model;
    @FXML
    private Button showButton;
    
    
    @FXML
    private void toMainPage(ActionEvent event) throws IOException {
        App.setRoot("mainPage");
        
    }

    public void setModel(StudentModel model){
        this.model = model;
    }

    @FXML
    private void showTable(ActionEvent event) {
        
        TreeItem<String> root = new TreeItem<>("Subjects");
        for(SubjectModel subject: model.getStudentSubjects()){
            TreeItem<String> subjectTemp = new TreeItem<>(subject.getSubjectName());
            //dodac to do roota
            for(Float grade: subject.getGrades()){
                TreeItem<String> gradeVal = new TreeItem<>(grade.toString());
                //dodać
                subjectTemp.getChildren().add(gradeVal);
            }
            //dodać
            root.getChildren().add(subjectTemp);
        }
        
        
        subjectColumn.setCellValueFactory(new Callback<TreeTableColumn.CellDataFeatures<String, String>, ObservableValue<String>>(){

            @Override
            public ObservableValue<String> call(TreeTableColumn.CellDataFeatures<String, String> param){
                return new SimpleStringProperty(param.getValue().getValue());
            }
        } );
        
       treeTableView.setRoot(root);
    }
}
