module pl.polsl.grade_book {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;

    opens pl.polsl.grade_book to javafx.fxml;
    exports pl.polsl.grade_book;
}
